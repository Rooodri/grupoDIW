<script setup>
import Cabecera from './components/Cabecera.vue'
import Cuerpo from './components/Cuerpo.vue'
</script>

<template>
  <header>
    <Cabecera titulo="app elena" contenido="Web es desarrollada por elena gata"/>
  </header>
  <hr>
  <main>
    <Cuerpo titulo="titulo cuerpo" contenido="contenido cuerpo"/>
  </main>
</template>

<style scoped>
</style>
