<script setup>
import servicioDatosProducto from '../servicios/servicioDatosProducto.js';
import { ref,onMounted } from "vue";

function obtenerProductos() {
    servicioDatosProducto.getAll()
    .then(response => {
        productos.value = response.data;
        console.log(response.data);
    })
    .catch(e => {
        console.log(e);
    });
}
</script>


<template>
    <div>
        <h1>Pagina listar</h1>
    </div>
</template>


<style scoped>

</style>