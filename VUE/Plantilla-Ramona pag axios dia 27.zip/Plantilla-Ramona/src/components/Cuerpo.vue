<script setup>
import { reactive, ref } from 'vue'

defineProps({
  titulo: {
    type: String,
    required: true
  },

  contenido: {
    type: String,
    required: true
  }
})

//JS ASOCIADO A PUNTO 1
//varibles a utilizar en el template
const contador = reactive({ cuenta: 0})
const mensaje = ref('Hola mundo')

//variables internas que no utilizare en el template
const autor = null;

console.log(mensaje.value)
console.log(contador.cuenta)

//JS ASOCIADO A PUNTO 2
let claseTitulo = ref('titulo')
setInterval(() => {
  (claseTitulo.value === "titulo2")? claseTitulo.value = "titulo":claseTitulo.value = "titulo2";
},1000)


//J2 ASOCIADO A PUNTO 3
//const contadorP4 = ref(0)

function incrementar() {
  contador.cuenta++
}
function decrementar() {
  contador.cuenta--
}

//JS ASOCIADO A PUNTO 4
const textoInput = ref('')
let claseTituloP4 = ref('')

//JS ASOCIADO A PUNTO 5
const visibilidad =ref(true)
function cambiar() {
  visibilidad.value = !visibilidad.value
}

//JS ASOCIADO A PUNTO 6
//***************************** VARIABLES */
let id = 0
const textoInput1="Especifica un valor"

const newTodo = ref('')
const todos = ref([
  { id: id++, text: 'Melocotones' },
  { id: id++, text: 'Lechuga' },
  { id: id++, text: 'Limones' }
])
 //*********************FUNCIONES */
function addTodo() {
  if(newTodo.value === "")  {
    console.log("El elemento no puede ser vacio")
  }else if(todos.value.find((e) => e.text === newTodo.value)){
    console.log("El elemento existe")
  }else{
    todos.value.push({ id: id++, text: newTodo.value })
    newTodo.value = ''
  }
}

function removeTodo(todo) {
  todos.value = todos.value.filter((t) => t !== todo)
  
}

//JS ASOCIADO A PUNTO 7

//JS ASOCIADO A PUNTO 8

//JS ASOCIADO A PUNTO 9

//JS ASOCIADO A PUNTO 10

//JS ASOCIADO A PUNTO 11

//JS ASOCIADO A PUNTO 12

//JS ASOCIADO A PUNTO 13

//JS ASOCIADO A PUNTO 14

</script>

<template>
  <h1>PUNTO 1: representación declarativa [reactividad]</h1>
  <p>Mensaje: {{ mensaje }}</p>
  <p>Cuenta: {{ contador.cuenta }}</p>
  <hr>

  <h1>PUNTO 2: titulos dinamicos</h1>
  <p :class="claseTitulo">ELENA</p>
  <hr>

  <h1>PUNTO 3: añadir funciones</h1>
  <button @click="incrementar">Incrementar</button>
  <p>El contador es {{ contador.cuenta }}</p>
  <button @click="decrementar">El contador es {{ contador.cuenta }}</button>
  <hr>

  <h1 :class="claseTituloP4">PUNTO 4: bindeo de input [{{ claseTituloP4 }}]</h1>
  <input v-model="claseTituloP4" placeholder="cambiar clase">
  <br>
  <input v-model="textoInput" placeholder="escribe algo">
  <p> {{ textoInput }}</p>
  <hr>

  <h1>PUNTO 5</h1>
  <button @click="cambiar">Cambiar</button>
  <h1 v-if="visibilidad">Hola Elena</h1>
  <h1 v-else>Hey</h1>
  <hr>

  <h1>PUNTO 6</h1>
    <form @submit.prevent="addTodo">
      <input v-model="newTodo" :placeholder="textoInput">
      
      <button>Añadir a Cesta</button>    
    </form>
    <ul>
      <li v-for="todo in todos" :key="todo.id">
        {{ todo.text }}
        <button @click="removeTodo(todo)">X</button>
      </li>
    </ul>
  <hr>

  <h1>PUNTO 7</h1>
  <hr>

  <h1>PUNTO 8</h1>
  <hr>

  <h1>PUNTO 9</h1>
  <hr>

  <h1>PUNTO 10</h1>
  <hr>

  <h1>PUNTO 11</h1>
  <hr>

  <h1>PUNTO 12</h1>
  <hr>

  <h1>PUNTO 13</h1>
  <hr>

  <h1>PUNTO 14</h1>
</template>

<style>
  .titulo {
    color: red;
  }

  .titulo2 {
    color: blue;
    text-align: right;
  }
</style>