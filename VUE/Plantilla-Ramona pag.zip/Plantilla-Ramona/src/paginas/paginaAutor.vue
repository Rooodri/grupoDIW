<script setup>

</script>

<template>
    <div>
        <h1>Pagina Autora</h1>
        <img src="../../public/img/foto.jpeg" alt="foto">
    </div>
</template>

<style scoped>
img {
    width: 550px;
}
</style>