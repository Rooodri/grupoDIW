<script setup>

</script>

<template>
    <div>
        <h1>Pagina listar</h1>
    </div>
</template>

<style scoped>

</style>