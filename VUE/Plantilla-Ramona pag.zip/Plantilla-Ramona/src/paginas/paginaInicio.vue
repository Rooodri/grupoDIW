<script setup>

</script>

<template>
    <div>
        <h1>Pagina Principal</h1>
    </div>
</template>

<style scoped>

</style>